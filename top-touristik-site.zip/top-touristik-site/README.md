
# TOP Touristik – Website

Dies ist die komplette Next.js + Tailwind Seite für TOP Touristik.

## So deployen Sie die Seite (ohne Programmierkenntnisse)

**A) GitHub & Vercel (empfohlen)**
1. Erstellen Sie ein kostenloses GitHub-Konto: https://github.com
2. Klicken Sie oben rechts auf **+** → **New repository** → Name: `top-touristik`
3. Öffnen Sie das neue Repository → **Add file** → **Upload files** →
   laden Sie den gesamten Inhalt dieser ZIP (alle Ordner/Dateien) hoch → **Commit changes**.
4. Gehen Sie zu https://vercel.com → kostenloses Konto erstellen und **GitHub verbinden**.
5. Klicken Sie **New Project** → wählen Sie `top-touristik` → Framework: **Next.js** → **Deploy**.

Nach ~1–2 Minuten erhalten Sie eine URL wie `https://top-touristik.vercel.app`.

**B) Vercel CLI (optional)**
– Nur falls Sie möchten: lokal `npm i`, dann `npx vercel`.

## Inhalte ändern
- Die Reiseangebote liegen im Code in `components/TravelOperatorMVP.tsx` in der Variable `demoPackages`.
- Im nächsten Schritt kann ein einfacher Bearbeitungsmodus (ohne Programmieren) ergänzt werden.
