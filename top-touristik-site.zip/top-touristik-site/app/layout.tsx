
import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "TOP Touristik – Reisen online buchen",
  description: "Unvergessliche Reisen – einfach online buchen mit TOP Touristik.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="de">
      <body>{children}</body>
    </html>
  );
}
