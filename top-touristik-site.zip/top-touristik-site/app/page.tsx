
import TravelOperatorMVP from "@/components/TravelOperatorMVP";

export default function Page() {
  return <TravelOperatorMVP />;
}
