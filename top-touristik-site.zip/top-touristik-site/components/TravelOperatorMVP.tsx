
"use client";
import React, { useEffect, useState } from "react";

export type Package = {
  id: string;
  title: string;
  destination: string;
  nights: number;
  basePriceCents: number; // pro Person
  img: string;
  highlights: string[];
  priceTotalCents: (guests: number, start: string, end: string) => number;
};

const demoPackages: Package[] = [
  {
    id: "gr-santorini",
    title: "Santorini Traumwoche",
    destination: "Griechenland",
    nights: 7,
    basePriceCents: 89900,
    img: "https://images.unsplash.com/photo-1504270997636-07ddfbd48945?q=80&w=1600&auto=format&fit=crop",
    highlights: ["4* Hotel mit Frühstück", "Inselrundfahrt", "Direktflug ab Wien"],
    priceTotalCents: (guests) => guests * 89900,
  },
  {
    id: "pt-algarve",
    title: "Algarve Sonne Pur",
    destination: "Portugal",
    nights: 5,
    basePriceCents: 69900,
    img: "https://images.unsplash.com/photo-1477587458883-47145ed94245?q=80&w=1600&auto=format&fit=crop",
    highlights: ["3* Hotel", "Mietwagen inklusive", "Küstenwanderung"],
    priceTotalCents: (guests) => guests * 69900,
  },
  {
    id: "eg-hurghada",
    title: "Rotes Meer All Inclusive",
    destination: "Ägypten",
    nights: 7,
    basePriceCents: 79900,
    img: "https://images.unsplash.com/photo-1491553895911-0055eca6402d?q=80&w=1600&auto=format&fit=crop",
    highlights: ["5* Resort AI", "Schnorcheln", "Transfer inklusive"],
    priceTotalCents: (guests) => guests * 79900,
  },
  {
    id: "it-sizilien",
    title: "Sizilien Kultur & Genuss",
    destination: "Italien",
    nights: 6,
    basePriceCents: 74900,
    img: "https://images.unsplash.com/photo-1507133750040-4a8f570215ed?q=80&w=1600&auto=format&fit=crop",
    highlights: ["Boutique Hotel", "Streetfood Tour", "Etna-Ausflug"],
    priceTotalCents: (guests) => guests * 74900,
  },
];

export default function TravelOperatorMVP() {
  const [step, setStep] = useState<"search" | "results" | "checkout" | "success" | "error">("search");
  const [loading, setLoading] = useState(false);
  const [query, setQuery] = useState({ destination: "Griechenland", start: "", end: "", guests: 2 });
  const [selected, setSelected] = useState<Package | null>(null);
  const [packages, setPackages] = useState<Package[]>(() => {
    if (typeof window === "undefined") return demoPackages;
    try {
      const raw = localStorage.getItem("tt_packages");
      return raw ? JSON.parse(raw) : demoPackages;
    } catch {
      return demoPackages;
    }
  });
  const [editMode, setEditMode] = useState(false);

  useEffect(() => {
    try { localStorage.setItem("tt_packages", JSON.stringify(packages)); } catch {}
  }, [packages]);

  function onSearch(e?: React.FormEvent) {
    e?.preventDefault();
    setStep("results");
  }

  function onSelect(pkg: Package) {
    setSelected(pkg);
    setStep("checkout");
  }

  async function onPay() {
    if (!selected) return;
    setLoading(true);
    try {
      await new Promise((r) => setTimeout(r, 1200));
      setStep("success");
    } catch (e) {
      console.error(e);
      setStep("error");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white text-slate-800">
      {/* Header */}
      <header className="sticky top-0 z-40 backdrop-blur bg-white/70 border-b border-slate-200">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-slate-900 text-white font-bold">TT</span>
            <span className="font-semibold">TOP Touristik</span>
          </div>
          <nav className="hidden md:flex items-center gap-6 text-sm">
            <a className="hover:text-slate-900" href="#angebote">Angebote</a>
            <a className="hover:text-slate-900" href="#vorteile">Vorteile</a>
            <a className="hover:text-slate-900" href="#kontakt">Kontakt</a>
          </nav>
          <div className="flex items-center gap-2">
            <button onClick={() => setEditMode((v)=>!v)} className="rounded-xl px-3 py-2 text-xs border border-slate-300 hidden sm:inline">{editMode ? "Bearbeiten: AN" : "Bearbeiten: AUS"}</button>
            <a href="#buchen" className="rounded-xl px-4 py-2 text-sm font-medium bg-slate-900 text-white hover:opacity-90">Jetzt buchen</a>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16 lg:py-24 grid lg:grid-cols-2 gap-10 items-center">
          <div>
            <h1 className="text-4xl/tight sm:text-5xl font-bold tracking-tight">
              Unvergessliche Reisen – einfach online buchen
            </h1>
            <p className="mt-4 text-slate-600 max-w-prose">
              Pauschalreisen, Rundreisen und individuelle Pakete für Gruppen & Familien. Planung, Buchung und sichere Online-Zahlung in einem Schritt.
            </p>
            <ul className="mt-6 grid grid-cols-2 gap-3 text-sm text-slate-600">
              <li className="flex items-center gap-2"><Dot/> TÜV/PCI-konforme Zahlung</li>
              <li className="flex items-center gap-2"><Dot/> Flexible Stornierung</li>
              <li className="flex items-center gap-2"><Dot/> Handverlesene Hotels</li>
              <li className="flex items-center gap-2"><Dot/> 24/7 Support</li>
            </ul>
          </div>
          <div id="buchen" className="bg-white rounded-2xl shadow-lg p-5 border border-slate-200">
            <h2 className="text-lg font-semibold mb-3">Reise suchen & buchen</h2>
            <BookingForm query={query} setQuery={setQuery} onSearch={onSearch} />
          </div>
        </div>
      </section>

      {/* Angebote */}
      <section id="angebote" className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12">
        <div className="flex items-end justify-between mb-6">
          <h2 className="text-2xl font-semibold">Beliebte Angebote</h2>
          <button onClick={onSearch} className="text-sm underline">Alle anzeigen</button>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {packages.slice(0,3).map((pkg) => (
            <PackageCard key={pkg.id} pkg={pkg} onSelect={onSelect} />
          ))}
        </div>
      </section>

      {/* Results / Checkout */}
      {step !== "search" && (
        <section className="bg-slate-50/60 border-t border-slate-200">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-10">
            {step === "results" && (
              <ResultsGrid
                query={query}
                packages={packages.filter(
                  (p) => p.destination.toLowerCase().includes(query.destination.toLowerCase())
                )}
                onSelect={onSelect}
              />
            )}

            {step === "checkout" && selected && (
              <Checkout
                selected={selected}
                query={query}
                onBack={() => setStep("results")}
                onPay={onPay}
                loading={loading}
              />
            )}

            {step === "success" && (
              <div className="bg-white rounded-2xl p-8 border border-emerald-200">
                <h3 className="text-2xl font-semibold text-emerald-700">Buchung bestätigt 🎉</h3>
                <p className="mt-2 text-slate-600">Sie erhalten in Kürze eine Bestätigung per E-Mail. Vielen Dank, und gute Reise!</p>
                <button className="mt-6 rounded-xl bg-slate-900 text-white px-4 py-2" onClick={() => setStep("search")}>Neue Reise suchen</button>
              </div>
            )}

            {step === "error" && (
              <div className="bg-white rounded-2xl p-8 border border-rose-200">
                <h3 className="text-2xl font-semibold text-rose-700">Zahlung fehlgeschlagen</h3>
                <p className="mt-2 text-slate-600">Bitte versuchen Sie es erneut oder wählen Sie eine andere Zahlungsart.</p>
                <button className="mt-6 rounded-2xl bg-slate-900 text-white px-4 py-2" onClick={() => setStep("checkout")}>Zurück zur Kasse</button>
              </div>
            )}
          </div>
        </section>
      )}

      {/* Vorteile */}
      <section id="vorteile" className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-14">
        <h2 className="text-2xl font-semibold mb-6">Warum bei uns buchen?</h2>
        <div className="grid md:grid-cols-3 gap-6">
          <Benefit title="Sichere Zahlung" desc="Integration mit Stripe, Mollie, PayPal oder Sofort/Klarna.">
            <Shield/>
          </Benefit>
          <Benefit title="Transparente Preise" desc="Alle Steuern & Gebühren klar ausgewiesen.">
            <Tag/>
          </Benefit>
          <Benefit title="Direkter Support" desc="Deutschsprachiger Service – per Telefon, Chat oder E-Mail.">
            <Headphones/>
          </Benefit>
        </div>
      </section>

      {/* Footer */}
      <footer id="kontakt" className="border-t border-slate-200 bg-white">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-10 grid md:grid-cols-4 gap-8 text-sm">
          <div>
            <div className="font-semibold">TOP Touristik</div>
            <p className="mt-2 text-slate-600">Ihr Partner für maßgeschneiderte Reisen in Europa & weltweit.</p>
          </div>
          <div>
            <div className="font-medium mb-2">Rechtliches</div>
            <ul className="space-y-2 text-slate-600">
              <li><a className="hover:underline" href="#">AGB</a></li>
              <li><a className="hover:underline" href="#">Datenschutz</a></li>
              <li><a className="hover:underline" href="#">Impressum</a></li>
            </ul>
          </div>
          <div>
            <div className="font-medium mb-2">Kontakt</div>
            <ul className="space-y-2 text-slate-600">
              <li>E‑Mail: office@top-touristik.at</li>
              <li>Adresse: 1010 Wien, Salzgries 19</li>
            </ul>
          </div>
          <div>
            <div className="font-medium mb-2">Newsletter</div>
            <form onSubmit={(e)=>{e.preventDefault(); alert("Danke! Wir melden uns bei Ihnen.");}} className="flex gap-2">
              <input type="email" required placeholder="Ihre E‑Mail" className="flex-1 rounded-xl border border-slate-300 px-3 py-2 outline-none focus:ring-2 focus:ring-slate-400"/>
              <button className="rounded-xl bg-slate-900 text-white px-4 py-2">Anmelden</button>
            </form>
          </div>
        </div>
      </footer>
    </div>
  );
}

function BookingForm({ query, setQuery, onSearch }: { query: any; setQuery: any; onSearch: any }) {
  return (
    <form onSubmit={onSearch} className="space-y-3">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div>
          <label className="text-sm text-slate-600">Reiseziel</label>
          <input
            value={query.destination}
            onChange={(e) => setQuery((q: any) => ({ ...q, destination: e.target.value }))}
            placeholder="z. B. Griechenland"
            className="mt-1 w-full rounded-xl border border-slate-300 px-3 py-2 outline-none focus:ring-2 focus:ring-slate-400"
          />
        </div>
        <div>
          <label className="text-sm text-slate-600">Gäste</label>
          <input
            type="number"
            min={1}
            value={query.guests}
            onChange={(e) => setQuery((q: any) => ({ ...q, guests: Number(e.target.value) }))}
            className="mt-1 w-full rounded-xl border border-slate-300 px-3 py-2 outline-none focus:ring-2 focus:ring-slate-400"
          />
        </div>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div>
          <label className="text-sm text-slate-600">Anreise</label>
          <input
            type="date"
            value={query.start}
            onChange={(e) => setQuery((q: any) => ({ ...q, start: e.target.value }))}
            className="mt-1 w-full rounded-xl border border-slate-300 px-3 py-2 outline-none focus:ring-2 focus:ring-slate-400"
          />
        </div>
        <div>
          <label className="text-sm text-slate-600">Abreise</label>
          <input
            type="date"
            value={query.end}
            onChange={(e) => setQuery((q: any) => ({ ...q, end: e.target.value }))}
            className="mt-1 w-full rounded-xl border border-slate-300 px-3 py-2 outline-none focus:ring-2 focus:ring-slate-400"
          />
        </div>
      </div>
      <button className="w-full rounded-xl bg-slate-900 text-white py-2.5 font-medium hover:opacity-90">Suchen</button>
    </form>
  );
}

function ResultsGrid({ query, packages, onSelect }: { query: any; packages: Package[]; onSelect: (p: Package) => void }) {
  return (
    <div>
      <div className="flex items-end justify-between mb-6">
        <h3 className="text-xl font-semibold">Suchergebnisse für „{query.destination}“</h3>
        <div className="text-sm text-slate-600">{packages.length} Angebot(e) gefunden</div>
      </div>
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {packages.map((pkg) => (
          <PackageCard key={pkg.id} pkg={pkg} onSelect={onSelect} />
        ))}
      </div>
    </div>
  );
}

function PackageCard({ pkg, onSelect }: { pkg: Package; onSelect: (p: Package) => void }) {
  return (
    <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm flex flex-col">
      <div className="aspect-[16/10] bg-slate-100">
        <img src={pkg.img} alt={pkg.title} className="w-full h-full object-cover" />
      </div>
      <div className="p-4 flex-1 flex flex-col">
        <div className="text-xs uppercase tracking-wide text-slate-500">{pkg.destination} • {pkg.nights} Nächte</div>
        <h4 className="mt-1 font-semibold text-lg">{pkg.title}</h4>
        <ul className="mt-2 text-sm text-slate-600 space-y-1">
          {pkg.highlights.map((h, i) => <li key={i} className="flex items-center gap-2"><Dot/>{h}</li>)}
        </ul>
        <div className="mt-4 flex items-center justify-between">
          <div className="font-semibold">ab {formatCents(pkg.basePriceCents)} p.P.</div>
          <button onClick={() => onSelect(pkg)} className="rounded-xl bg-slate-900 text-white px-3 py-2 text-sm">Jetzt buchen</button>
        </div>
      </div>
    </div>
  );
}

function Checkout({ selected, query, onBack, onPay, loading }: { selected: Package; query: any; onBack: () => void; onPay: () => void; loading: boolean; }) {
  const total = selected.priceTotalCents(query.guests, query.start, query.end);
  return (
    <div className="grid lg:grid-cols-3 gap-8">
      <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200 p-6">
        <h3 className="text-xl font-semibold">Buchung abschließen</h3>
        <div className="mt-4 grid sm:grid-cols-2 gap-4">
          <Field label="Reiseziel" value={`${selected.destination}`} />
          <Field label="Reise" value={`${selected.title} (${selected.nights} Nächte)`} />
          <Field label="Anreise" value={query.start || "—"} />
          <Field label="Abreise" value={query.end || "—"} />
          <Field label="Gäste" value={String(query.guests)} />
          <Field label="Gesamt" value={formatCents(total)} />
        </div>
        <div className="mt-6 text-sm text-slate-600">Mit der Buchung akzeptieren Sie unsere AGB und Datenschutzbestimmungen.</div>
        <div className="mt-6 flex gap-3">
          <button onClick={onBack} className="rounded-xl border border-slate-300 px-4 py-2">Zurück</button>
          <button disabled={loading} onClick={onPay} className="rounded-xl bg-slate-900 text-white px-4 py-2 disabled:opacity-60">{loading ? "Wird verarbeitet…" : "Jetzt bezahlen"}</button>
        </div>
      </div>
      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
        <img src={selected.img} alt="Ausgewähltes Paket" className="w-full h-40 object-cover" />
        <div className="p-5 text-sm text-slate-700">
          <div className="font-medium">Inklusive</div>
          <ul className="mt-2 space-y-1">
            {selected.highlights.map((h, i) => <li key={i} className="flex items-center gap-2"><Dot/>{h}</li>)}
          </ul>
        </div>
      </div>
    </div>
  );
}

function Field({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <div className="text-xs uppercase tracking-wide text-slate-500">{label}</div>
      <div className="mt-1 font-medium">{value}</div>
    </div>
  );
}

function Benefit({ title, desc, children }: { title: string; desc: string; children: React.ReactNode }) {
  return (
    <div className="bg-white rounded-2xl border border-slate-200 p-6">
      <div className="h-10 w-10 rounded-xl bg-slate-900 text-white flex items-center justify-center">{children}</div>
      <div className="mt-3 font-semibold">{title}</div>
      <div className="text-slate-600 text-sm mt-1">{desc}</div>
    </div>
  );
}

function Dot() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" className="text-slate-400">
      <circle cx="12" cy="12" r="4" />
    </svg>
  );
}
function Shield() {
  return (
    <svg viewBox="0 0 24 24" className="w-5 h-5" fill="currentColor"><path d="M12 2l7 4v6c0 5-3.4 9.7-7 10-3.6-.3-7-5-7-10V6l7-4z"/></svg>
  );
}
function Tag() {
  return (
    <svg viewBox="0 0 24 24" className="w-5 h-5" fill="currentColor"><path d="M10 3l9 9-7 7-9-9V3h7zm0 2H6v4l7 7 5-5-8-8z"/></svg>
  );
}
function Headphones() {
  return (
    <svg viewBox="0 0 24 24" className="w-5 h-5" fill="currentColor"><path d="M12 3a9 9 0 00-9 9v6a3 3 0 003 3h1v-8H6a7 7 0 0114 0h-1v8h1a3 3 0 003-3v-6a9 9 0 00-9-9z"/></svg>
  );
}

function formatCents(cents: number) {
  return new Intl.NumberFormat("de-AT", { style: "currency", currency: "EUR" }).format(cents / 100);
}
